<?php
	ini_set('display_errors',1);//delete befor going live
	error_reporting(E_ALL);//delete befor going live

	require_once("phpscripts/init.php");
	$ip = $_SERVER["REMOTE_ADDR"];
	//echo $ip;
	
	if(isset($_POST['submit'])){
		//echo "thanks for click";
		$username= trim($_POST['username']);
		$password= trim($_POST['password']);
		//$password_hashed = password_hash($password, PASSWORD_DEFAULT);
		//echo "$password_hashed";
		if($username != "" && $password != ""){
			$result= logIn($username, $password, $ip);
			$message = $result;
		}else{
			$message = "Insert correct details in empty boxes";
		}
	}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>New Admin Panel</title>
<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
	<div id=headSection>
		<h1>Welcome To Admin Panel</h1>
	</div>
	<div>
		<img src="images/name.png" alt="myName" width="250" class="myNameM">
	</div>
	<p class="headingText">Welcome To Our Admin Panel.<br>For Process Forward, Please Enter your Valid Id and Password</p>
	<p class="name1">Design by <span class="name">Milind</span>
	<div id=headSection2>
		<p>Sign In</p>
		<img src="images/signIn.png" width="300" class="signInImage">
	</div>
	<form id="loginBox" action="admin_login.php" method="post">
		<p id="message"><?php if(!empty($message)){echo $message;} ?></p>
		<input type="text" name="username" class="fields" placeholder="username">
		<input type="password" name="password" class="fields" placeholder="password">
		<input type="submit" name="submit" value="Sign In">
	</form>
	<br><br>
	<p class="headingText">Login ID:<span class="name3">fanshawe</span><br>
	Password:<span class="name3">a8238420</span></p>
	<br><br><br><br>

</body>
</html>