<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Movie</title>
</head>
<body>
<?php  phpinfo(); ?>
</body>
</html>