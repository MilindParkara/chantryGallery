<?php
	ini_set('display_errors',1);
	error_reporting(E_ALL);
require_once("phpscripts/init.php");
//call to function to check if logged in
//confirm_logged_in();
//Login would need to be rigged, due Week feb 13th
//Check to see if someone clicked on submit button
if(isset($_POST['submit'])) {
	// --echo "works";
	
	$fname = trim($_POST['fname']);
	$lname = trim($_POST['lname']);
	$username = trim($_POST['username']);
	$email = trim($_POST['email']);
	$password_plain  = bin2hex(openssl_random_pseudo_bytes(4));
	$password  = password_hash($password_plain, PASSWORD_DEFAULT);

	$level = $_POST['lvllist'];
	
	if(empty($level)) {
		 echo "Level Not Selected";
		$message = "Please select a user level.";
	}else{
		echo "Level Selected<br>";

$message = "			
						Hello $fname,
						<br /><br />
						Welcome to $fname <br/>
						You userID is $username </br>
						Your password to login to the site is <br>
						$password_plain
						<br /><br />you can ling here </a>
						<br /><br />
						Thanks,";
						
			$subject = "login details ";
			$mail=send_mail($email,$message,$subject);	
		  	$message2 = $mail;
			$result = createUser($fname, $lname, $username, $password, $level, $email);
echo"succes";
		  $message1 = $result;
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Create User</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
<div id=headSection>
		<h1>Welcome  Admin, Create A New User </h1>
	</div><br><br><br><br><br>
<?php if(!empty($message)){echo $message;}?>
<form action="admin_createuser.php" method="post" id="loginBox" >
<label for="">First Name:</label>
<input name="fname" type="text" value="<?php if(!empty($fname)){echo $fname;}?>">
<label for="">Last Name:</label>
<input name="lname" type="text" value="<?php if(!empty($lname)){echo $lname;}?>">
<label for="">User Name:</label>
<input name="username" type="text" value="<?php if(!empty($username)){echo $username;}?>">
<label for="">Email:</label>
<input name="email" type="text" value="<?php if(!empty($email)){echo $email;}?>">

<!--created password but system should generate-->
<br><br>
<select name="lvllist" style="padding-left: 5rem;
    margin-left: 18px;
    width: 29rem;
    height: 3rem;">
	<option value="">*Please Select User Level*</option>
    <option value="2">Standard Admin</option>
    <option value="1">Super Master</option>
</select>
<br><br>
<input type="submit" name="submit" value="Create User">

</form>
<br><br>
<a href="admin_index.php" class="btn2">< Back</a>

</body>
</html>