
<?php
	require_once('phpscripts/init.php');
	//confirm_logged_in();
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin pannel</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id=headSection>
		<h1>Welcome  Admin </h1>
	</div>
	<h2>Good <?php echo$_SESSION['salutation']; echo $_SESSION['users_name']; ?></h2>
	<div id="loginBox">
		
		<br>
		<h3 class="headingText2"><?php echo $_SESSION['last_login']; ?>
		<br>
		<?php
		if ($_SESSION['user_level'] == 1){
			echo'<a href="admin_createuser.php" class="btn">Create New User</a>';
			echo'<a href="admin_edituser.php" class="btn">Edit User Details</a>';
		}
		else{
		   	echo'<a href="admin_edituser.php" class="btn">Edit User</a>';
		}
		?>
		<br><br><br>
		<a href="phpscripts/caller.php?caller_id=logout" id="logOut" class="btn2">
		Log Out
		</a>
	</div>
</body>
</html>