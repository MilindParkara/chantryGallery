<?php
	ini_set('display_errors',1);//delete befor going live
	error_reporting(E_ALL);//delete befor going live

	require_once("phpscripts/init.php");
	$ip = $_SERVER["REMOTE_ADDR"];
	//echo $ip;
	
	if(isset($_POST['submit'])){
		//echo "thanks for click";
		$username= trim($_POST['username']);
		$password= trim($_POST['password']);
		//$password_hashed = password_hash($password, PASSWORD_DEFAULT);
		//echo "$password_hashed";
		if($username != "" && $password != ""){
			$result= logIn($username, $password, $ip);
			$message = $result;
		}else{
			$message = "Insert correct details in empty boxes";
		}
	}
?>
<!doctype html>
</html>
<html>
<head>
<meta charset="UTF-8">
<title>Client Login</title>
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>
<div id=headSection>
	<h1>Welcome To Admin Panel</h1>
</div>
	<h1>Admin Login</h1>
	<form id="loginBox" action="admin_login.php" method="post">
		<p id="message"><?php if(!empty($message)){echo $message;} ?></p>
		<input type="text" name="username" class="fields" placeholder="username">
		<input type="password" name="password" class="fields" placeholder="password">
		<input type="submit" name="submit" value="GO">
	</form>
</body>
</html>