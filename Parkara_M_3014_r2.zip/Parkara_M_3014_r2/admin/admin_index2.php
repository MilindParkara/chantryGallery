<?php
	require_once('phpscripts/init.php');
	//confirm_logged_in();
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin pannel</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<h1>Welcome Admin</h1>
	<div id="loginBox">
		<h2>Good <?php echo$_SESSION['salutation']; echo $_SESSION['users_name']; ?>Welcome to CMS PANEL</h2>
		<br>
		<h3><?php echo $_SESSION['last_login']; ?>
		<br>
		<?php
		if ($_SESSION['user_level'] == 1){
			echo'<a href="admin_createuser.php">create User</a>';
			echo'<a href="admin_edituser.php">Edit User</a>';
		}
		else{
		   	echo'<a href="admin_edituser.php">Edit User</a>';
		}
		?>
		<br>
		<a href="phpscripts/caller.php?caller_id=logout" id="logOut">
		Log Out
		</a>
	</div>
</body>
</html>