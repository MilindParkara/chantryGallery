<?php
	function logIn($username, $password, $ip) {
		//First place anyone tries to attack is the login, bury it in the admin folder, restrict access by IP address, that sort of thing. Double up on security.
		
		require_once("connect.php");
		$username = mysqli_real_escape_string($link, $username); //checks for slashes and cancels out injection commands, treats as a string rather than a command line. 
		$password = mysqli_real_escape_string($link, $password);	 //You can set users, user level (Access to certain pages), webmaster and admin, etc in PHP Database. 
		$loginString = "SELECT * FROM tbl_user WHERE user_name='{$username}' AND user_pass='{$password}'";
			//echo $loginString;
		
			//Below is to check if user exists or return an error if they do not.
			$user_set = mysqli_query($link, $loginString);
			
			if(mysqli_num_rows($user_set)) { //Checks database to see if a result will be returned or not (The number of the rows)
				$found_user = mysqli_fetch_array($user_set, MYSQLI_ASSOC); //Associative array, we don't need to worry about indexing or anyhting like that.
				echo $found_user['user_id'];
				//sesion variable = temp global variable
				$_SESSION['users_id'] = $id;
			$_SESSION['users_name'] = $found_user['user_name'];
			if(mysqli_query($link, $loginString)){
				$updateString = "UPDATE tbl_user SET user_ip = '{$ip}' WHERE user_id={$id}";
				$updateQuery =mysqli_query($link, $updateString);
			}
			redirect_to("admin_index.php");
		} else{
			$message = "Username/Password is not correct. <br>Please check beofre you entered details";
			return $message;
		}
		mysqli_close($link);
	}
?>