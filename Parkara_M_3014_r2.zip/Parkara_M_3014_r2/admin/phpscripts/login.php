<?php

function logIn($username, $password, $ip)
{
    require_once('connect.php');
    $username    = mysqli_real_escape_string($link, $username);
    $password    = mysqli_real_escape_string($link, $password); //cleans string, removes slashes quotes ext.
    $loginString = "SELECT * FROM tbl_user WHERE user_name='{$username}'";
    //echo $loginString;	
    $user_set    = mysqli_query($link, $loginString);
    if (mysqli_num_rows($user_set)) {
        $found_user = mysqli_fetch_array($user_set, MYSQLI_ASSOC);
        if (password_verify($password, $found_user['user_pass'])) {
            
            $id                     = $found_user['user_id'];
            // $dateTime               = $found_user['user_lastlogin'];
            $attempts               = $found_user['user_attempts'];
            //sesion variable = temparary grobal variable
            $_SESSION['users_id']   = $id;
            $_SESSION['users_name'] = $found_user['user_name'];
            $_SESSION['last_login'] = "";
            $_SESSION['user_level'] = $found_user['user_level'];
            date_default_timezone_set("EST");
            if ($attempts > 2) {
                $message = "user locked out, please contact system administrator";
                return $message;
            } else {
//                if ($found_user['user_lastlogin'] != "new_user") {
//                    $_SESSION['last_login'] = 'your last sucessful login was ' . $dateTime;
//                }
                $time = date("H");
                if ($time < 12) {
                    $welcome = "morning ";
                } else if ($time > 11 and $time < 18) {
                    $welcome = "afternoon ";
                } else {
                    $welcome = "evening ";
                }
                $_SESSION['salutation'] = $welcome;
                $dateTime               = date("g:i a M d Y");
                $updateTime             = "UPDATE tbl_user SET user_lastlogin = '{$dateTime}' WHERE user_id={$id}";
                $updateQuery            = mysqli_query($link, $updateTime);
                
                if (mysqli_query($link, $loginString)) {
                    $updateString = "UPDATE tbl_user SET user_ip = '{$ip}' WHERE user_id={$id}";
                    $updateQuery  = mysqli_query($link, $updateString);
                }
                $attempts       = 0;
                $updateAttempts = "UPDATE tbl_user SET user_attempts = '{$attempts}' WHERE user_id={$id}";
                $updateQuery    = mysqli_query($link, $updateAttempts);
                redirect_to("admin_index.php");
            }
        } else {
            echo "password do not match";
        }
        
    } else {
        $usernameString = "SELECT * FROM tbl_user WHERE user_name='{$username}'";
        $user_set       = mysqli_query($link, $usernameString);
        $found_user     = mysqli_fetch_array($user_set, MYSQLI_ASSOC);
        $id             = $found_user['user_id'];
        $attempts       = $found_user['user_attempts'];
        $attempts       = $attempts + 1;
        $updateAttempts = "UPDATE tbl_user SET user_attempts = '{$attempts}' WHERE user_id={$id}";
        $updateQuery    = mysqli_query($link, $updateAttempts);
        
        $message = "Username/Password where incorrect. <br>Plaease make sure your caps lock key is turned off.";
        return $message;
    }
    mysqli_close($link);
}
?>