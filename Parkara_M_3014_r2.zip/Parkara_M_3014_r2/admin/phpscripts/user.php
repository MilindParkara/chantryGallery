<?php
function editUser($id, $fname, $lname, $username, $password){
	include("connect.php");

	$updateString = "UPDATE tbl_user SET user_fname = '{$fname}', user_lname = '{$lname}', user_name = '{$username}', user_pass = '{$password}' WHERE user_id={$id}";
	$updatequery = mysqli_query($link, $updateString);
	if ($updatequery){
		redirect_to("admin_index.php");
	}else{
		$message = "There was a problem. Please contact a admin for help.";
		return $message;
	}
	mysqli_close($link);
}

function getUser($id){
	require_once("connect.php");
	$userString = "SELECT * FROM tbl_user WHERE user_id ='{$id}'";
	$userquery = mysqli_query($link, $userString);
	if($userquery){
		$found_user = mysqli_fetch_array($userquery, MYSQLI_ASSOC);
		return $found_user;
	}else{
		$message = "There was a problem to change details in your account. Please contact a admin for help.";
		return $message;
	}
	mysqli_close($link);
}


function createUser($fname, $lname, $username, $password, $level,$email){
		require_once("connect.php");
	 $ip = 0;
	 $user_attempts=0;
	 $userstring = "INSERT INTO tbl_user VALUES(NULL, '{$fname}','{$lname}','{$username}','{$password}','{$level}','{$ip}','{$email}','{$user_attempts}')"; 
	 	//echo $userstring;
		
		$userquery = mysqli_query($link, $userstring);
		if($userquery){
			redirect_to("admin_index.php");
		}else{
			$message = "There was an error in creating this user, please try again later...";
			return $message;
		}
		mysqli_close($link);
	}

?>