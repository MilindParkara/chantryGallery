<?php
	
	function redirect_to($location) {
		if($location != NULL) {
			header("Location: {$location}");
			exit;
		}
	}
	function addMovie($fimg,$thumb,$title,$year,$storyline,$runtime,$trailer,$price,$cat){
		include('connect.php');
		$fimg = mysqli_real_escape_string($link, $fimg);

		if($_FILES['movie_fimg']['type'] == "image/jpg" || $_FILES['movie_fimg']['type'] == "image/jpeg") {
			$targetpath = "../images/{$fimg}";
			if(move_uploaded_file($_FILES['movie_fimg']['tmp_name'],$targetpath)){ 
			//moves file to a temp folder and checks if it has been moved
				$orig = "../images/".$fimg;
				$th_copy = "../images/".$thumb;

				if(!copy($orig,$th_copy)){
					echo "failed to copy image";
				}
				$size = getimagesize($orig);
				echo $size[0]." x ".$size[1];
				//gd lybrary
			}
		}
		mysqli_close($link);
	}

	function send_mail($email,$message,$subject)
	{						
		require_once('mailer/class.phpmailer.php');
		$mail = new PHPMailer();
		$mail->IsSMTP(); 
		$mail->SMTPDebug  = 0;                     
		$mail->SMTPAuth   = true;                  
		$mail->SMTPSecure = "ssl";                 
		$mail->Host       = "smtp.gmail.com";      
		$mail->Port       = 465;             
		$mail->AddAddress($email);
		$mail->Username="oliviastinson2@gmail.com";  
		$mail->Password="Yahoo@123";            
		$mail->SetFrom('oliviastinson2@gmail.com','Milind Parkara');
		$mail->AddReplyTo("oliviastinson2@gmail.com","Milind Parkara");
		$mail->Subject    = $subject;
		$mail->MsgHTML($message);
		$mail->Send();
	}	
	

?>